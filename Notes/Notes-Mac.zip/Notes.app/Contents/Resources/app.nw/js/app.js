/*

Calcul de la moyenne générale

© Guillaume Gonnet
License GPLv2

*/



var Window = require("nw.gui").Window.get();


// F12 pour sortir la console
window.addEventListener('keydown', function (e) {
	if (e.keyIdentifier === 'F12') {
		Window.showDevTools();
	}
});


// Boutton close
$("#titlebar .close").click(function() {
	Window.close();
});


// Event on close
Window.on('close', function() {
	this.hide();

	if (!Options.autoLogin) {
		localStorage.clear();
	}

	this.close(true);
});




const version = [0,2,1];
var serverInfos;


// Fonction d'initialisation
function init() {
	checkForUpdate();
	if (Options.autoLogin && localStorage.pseudo && localStorage.mdp) {
		$("#loginName").val(localStorage.pseudo);
		$("#loginMdp").val(localStorage.mdp);
		$("#login").submit();
	}
}


// Recherche des mise à jour
function checkForUpdate() {
	if (!serverInfos || !Options) return;
	var serverVersion = serverInfos.version.split(".")
	if (serverVersion[0] != version[0] || serverVersion[1] != version[1]) {
		if (confirm("Une nouvelle version de Notes est disponible.\nVoulez-vous la télécharger ?"))
			require('nw.gui').Shell.openExternal("http://parksprojets.github.io/Notes");
	}
}


// On obtient les infos du server
$.get("http://parksprojets.github.io/Notes/infos.json", function(d) {
	serverInfos = d;
	checkForUpdate();
});





// Fonctions utiles

function calculerMoyenne(data, classe) {
	if (data.length == 0)  return 0;

	var sommePond = 0, surCombien = 0;

	for (var i in data) {
		if ((classe?data[i].moyenne:data[i].note) >= 0) {
			surCombien += data[i].surCombien * data[i].coefficient;
			sommePond += (classe?data[i].moyenne:data[i].note) * data[i].coefficient;
		}
	}

	return Math.round(sommePond * 200 / surCombien) / 10;
}



function parseDate(date) {
	return Date.parse(date.replace(/([0-9]+)\/([0-9]+)/, "$2/$1"));
}





// Variables générales
var baseUrl = "", eleveId = 0, matieres = [];





// Login

$("#login").submit(function(e) {

	e.preventDefault();
	$("#login p").fadeOut();
	$("#cache").fadeIn();

	var pseudo = $("#loginName").val(), mdp = $("#loginMdp").val();


	// On envoi les infos à la page deconnexion
	$.ajax({
		url: Options.baseUrl + "/login/ct_logon_vk.jsp",
		method: "post",
		data: {
			auth_mode: "BASIC",
			orig_url: "/ts",
			user: pseudo,
			password: mdp
		},

		success: function(d, status, xhr) {

			// Mdp et pseudo corrects
			if (d.search("Identifiant ou mot de passe incorrect") == -1) {
				
				localStorage.pseudo = pseudo;
				localStorage.mdp = mdp;

				lanceApp();
			}

			// Mdp ou pseudo incorrect
			else {
				$("#cache").fadeOut(function() {
					$("#login p:eq(0)").fadeIn();
				});
			}
		},

		error: function(d) {
			// Problème réseau
			$("#cache").fadeOut(function() {
				$("#login p:eq(1)").fadeIn();
			});
		}
	});

});


function lanceApp() {
	$("#login").hide();
	$("#view").show();

	$.get(baseUrl, function(d) {
		eleveId = d[0].id;

		$("#name").text(d[0].prenom + " " + d[0].nom).fadeIn();

		// On obtient les matières existante
		$.get(baseUrl+eleveId+"/matieres", function(mats) {
			matieres = mats;
			for (var i in mats) {
				var $elem = $('<div data-i="'+i+'" data-id="'+mats[i].id+'">'+mats[i].libelle+'</div>');
				$elem.click(onClickMatiere);
				$("#matieres .mats").append($elem);
			}

			$("#cache").fadeOut();
		});
	});
}