var Window = require("nw.gui").Window.get();


window.addEventListener('keydown', function (e) {
	if (e.keyIdentifier === 'F12') {
		Window.showDevTools();
	}
});


$("#titlebar .icon-close").click(function() {
	Window.close();
});




const baseUrl = "https://services.ac-lyon.fr/ts-mobile/resources/eleves/";

var eleveId = 0;
var matieres = [];

var login = $("#login")[0];
var timer = setInterval(function() {

	if (login.contentWindow.location.href == "https://services.ac-lyon.fr/ts/") {
		clearInterval(timer);
		login.style.display = "none";
		$("#view").show();
		$("#cache").fadeIn();

		$.get(baseUrl, function(d) {
			eleveId = d[0].id;

			$("#name").text(d[0].prenom + " " + d[0].nom).fadeIn();


			$.get(baseUrl+eleveId+"/matieres", function(mats) {
				matieres = mats;
				for (var i in mats) {
					var $elem = $('<div data-i="'+i+'" data-id="'+mats[i].id+'">'+mats[i].libelle+'</div>');
					$elem.click(onClickMatiere);
					$("#matieres .mats").append($elem);
				}

				$("#cache").fadeOut();
			});
		});
	}

}, 50);



function parseDate(date) {
	return Date.parse(date.replace(/([0-9]+)\/([0-9]+)/, "$2/$1"));
}



var currentNotes = [[],[],[],[]], currentLength = 0, nbrRecieved = 0;
var time2Trim = 0,
	time3Trim = 0;

// Quand on click sur une mtière
function onClickMatiere() {

	currentNotes = [[],[],[],[]];
	$("#cache").fadeIn();

	var id = $(this).attr("data-id"),
		index = $(this).attr("data-i"),
		titre = $(this).text();

	// On récupère les notes
	$.get(baseUrl+eleveId+"/matieres/"+id+"/controles/?index=0&offset=200", function(d) {
		
		console.log(d);

		// On met le titre
		$("#notes h3 span").text(titre);

		// On enlève les anciennes notes
		$("#noteContent p").remove();
		$("#noteContent div").show();

		
		// On récupère les date des trimestres
		time2Trim = parseDate(Options.deuxiemeTrimestre);
		time3Trim = parseDate(Options.troisiemeTrimestre);


		var moyenne = [0,0,0,0];
		var surCombien = [0,0,0,0];

		currentLength = d.length;
		nbrRecieved = 0;

		for (var i in d) {
			
			// On choisis le trimestre qui correspond à la note
			var index = 3;
			if (d[i].date < time2Trim)
				index = 1;
			else if (d[i].date < time3Trim)
				index = 2;

			$("#noteContent .c"+index+"Trim").append('<p data-id='+d[i].id+'></p>');
			$.get(baseUrl+eleveId+"/matieres/"+id+"/controles/"+d[i].id+"?index=&offset=", onNoteRecieve);
		}


		for (var i = 1; i <= 3; i++) {
			if ($("#noteContent .c"+i+"Trim p").length == 0) {
				$("#noteContent .c"+i+"Trim").hide();
			}
		}

		// On affiche les notes
		$("#matieres").css("margin-left", "-50%");
	});
}



function onNoteRecieve(d) {
	var $elem = $("#noteContent p[data-id="+d.id+"]");

	var index = 3;
	if (d.date < time2Trim)
		index = 1;
	else if (d.date < time3Trim)
		index = 2;

	currentNotes[index].push(d);
	currentNotes[0].push(d);


	$elem.append(d.libelle + ': ');

	if (d.note != -1)
		$elem.append(d.note+' / '+d.surCombien);
	else
		$elem.append('Abs');

	$elem.append(' &nbsp;&nbsp;&nbsp; coeff: '+d.coefficient);
	$elem.append('<br><small>Le '+new Date(d.date).toLocaleDateString()+', &nbsp;&nbsp;&nbsp; Min: '+parseFloat(d.noteMin)+' &nbsp;&nbsp;&nbsp; Moy: '+parseFloat(d.moyenne)+' &nbsp;&nbsp;&nbsp; Max: '+parseFloat(d.noteMax)+'</small>');

	updateNoteRecieve();
}



function updateNoteRecieve() {
	nbrRecieved++;
	if (nbrRecieved >= currentLength) {
		for (var i = 1; i <= 3; i++) {
			$("#noteContent .c"+i+"Trim h4 span").text(calculerMoyenne(currentNotes[i]));
			$("#noteContent .c"+i+"Trim h4 small").text('Classe: '+calculerMoyenne(currentNotes[i], true));
		}

		$("#notes .moyenne span").text(calculerMoyenne(currentNotes[0]))
		$("#notes .moyenne small").text('Classe: '+calculerMoyenne(currentNotes[0], true));

		$("#cache").fadeOut();
	}
}




function calculerMoyenne(data, classe) {
	if (data.length == 0)  return 0;

	var sommePond = 0, surCombien = 0;

	for (var i in data) {
		if ((classe?data[i].moyenne:data[i].note) >= 0) {
			surCombien += data[i].surCombien * data[i].coefficient;
			sommePond += (classe?data[i].moyenne:data[i].note) * data[i].coefficient;
		}
	}

	return Math.round(sommePond * 200 / surCombien) / 10;
}






/* Moyenne générale */

var genLength = 0, currentGenLength = 0;
var genNotes = [];

$("#matieres .moyenne button").click(function() {

	if ($(this).hasClass('off'))  return;

	$("#matieres .moyenne img").css("opacity", 1);
	$(this).addClass('off');
	$("#matieres .moyenne .result").css("opacity", 0);

	var selected = $("#matieres .moyenne option:selected").val();
	var min = 0, max = 0;
	genNotes = [];

	if (selected == "trim1") {
		max = parseDate(Options.deuxiemeTrimestre);
	}
	else if (selected == "trim2") {
		min = parseDate(Options.deuxiemeTrimestre);
		max = parseDate(Options.troisiemeTrimestre);
	}
	else if (selected == "trim3") {
		min = parseDate(Options.troisiemeTrimestre);
	}


	matieres.forEach(function(mat, i) {
		$.get(baseUrl+eleveId+"/matieres/"+mat.id+"/controles/?index=0&offset=200", function(d) {
			
			for (var i in d) {

				if ((!min || d[i].date >= min) && (!max || d[i].date <= max)) {
					genLength++;
					$.get(baseUrl+eleveId+"/matieres/"+mat.id+"/controles/"+d[i].id+"?index=&offset=", onNotesGenRec);
				}
			}

			if (i >= matieres.length && genLength == 0) {
				$("#matieres .moyenne img").css("opacity", 0);
				$("#matieres .moyenne button").removeClass('off');
			}

		});
	});
});



function onNotesGenRec(d) {
	genNotes.push(d);
	updateGenRec();
}


function updateGenRec() {
	currentGenLength++;
	if (currentGenLength >= genLength) {
		$("#matieres .moyenne img").css("opacity", 0);
		$("#matieres .moyenne button").removeClass('off');

		$("#matieres .moyenne .result span:eq(0)").text(calculerMoyenne(genNotes));
		$("#matieres .moyenne .result span:eq(1)").text(calculerMoyenne(genNotes, true));
		$("#matieres .moyenne .result").css("opacity", 1);
	}
}





$("#notes i").click(function() {
	$("#matieres").css("margin-left", 0);
});