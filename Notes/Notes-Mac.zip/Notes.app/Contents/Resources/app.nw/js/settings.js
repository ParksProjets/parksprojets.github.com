var fs = require("fs"),
	Options = {};

var settingOpened = false;
$("#titlebar .icon-cog").click(function() {
	if (settingOpened)
		$("#view, #login").css("margin-top", -0);
	else
		$("#view, #login").css("margin-top", (-$(window).height()+50)+"px");

	settingOpened = !settingOpened;
});

$(".date").datepicker();





function updateOptionFile() {
	fs.writeFile("js/options.json", JSON.stringify(Options), function(err) {
		if (err)
			console.error("updateOptionFile: Impossible d'écrire dans le fichier");
	});
}


fs.readFile("js/options.json", function(err, data) {
	if (err) {
		console.error("Impossible de lire le fichier options.json");
		return;
	}

	var obj = JSON.parse(data);
	Options = obj;

	$("#settings .date:eq(0)").val(obj.deuxiemeTrimestre);
	$("#settings .date:eq(1)").val(obj.troisiemeTrimestre);
});



$("#settings .date:eq(0)").change(function() {
	Options.deuxiemeTrimestre = $(this).val();
	updateOptionFile();
});


$("#settings .date:eq(1)").change(function() {
	Options.troisiemeTrimestre = $(this).val();
	updateOptionFile();
});