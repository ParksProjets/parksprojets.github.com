/*

Options

© Guillaume Gonnet
License GPLv2

*/


var fs = require("fs"),
	Options;


// Init
$(".date").datepicker();



// Boutton "*"
var settingOpened = false;
$("#titlebar .cog").click(function() {
	if (settingOpened)
		$("#view, #login").css("margin-top", -0);
	else
		$("#view, #login").css("margin-top", (-$(window).height()+50)+"px");

	settingOpened = !settingOpened;
});




// Function pour changer la couleur

var couleurs = ["rose", "bleu", "vert", "jaune"];

function switchColorTo(i) {
	if (i === Options.couleur)  return;

	$("#colorSelector span").removeClass('on');
	$("#colorSelector span:eq("+i+")").addClass('on');
	$("body").removeClass(couleurs.join(" ")).addClass(couleurs[i]);
	Options.couleur = i;
}






/* Fichier options.json */


// Met à jour le fichier
function updateOptionFile() {
	fs.writeFile("js/options.json", JSON.stringify(Options), function(err) {
		if (err)
			console.error("updateOptionFile: Impossible d'écrire dans le fichier");
	});
}



// Lecture du fichier
fs.readFile("js/options.json", function(err, data) {
	if (err) {
		console.error("Impossible de lire le fichier options.json");
		return;
	}

	Options = {};

	var obj = JSON.parse(data);

	$("#settings .date:eq(0)").val(obj.deuxiemeTrimestre);
	$("#settings .date:eq(1)").val(obj.troisiemeTrimestre);

	$("#loginAuto")[0].checked = obj.autoLogin;

	$("#urlTs").val(obj.baseUrl);
	baseUrl = obj.baseUrl + "/ts-mobile/resources/eleves/";

	switchColorTo(obj.couleur);

	Options = obj;
	init();
});







/* Events des input de l'option */


// Date trimestres

$("#settings .date:eq(0)").change(function() {
	Options.deuxiemeTrimestre = $(this).val();
	updateOptionFile();
});


$("#settings .date:eq(1)").change(function() {
	Options.troisiemeTrimestre = $(this).val();
	updateOptionFile();
});


$("#opTrims h4 span").click(function() {
	if (!serverInfos) return;

	$("#settings .date:eq(0)").val(serverInfos.settings.deuxiemeTrimestre).trigger('change');
	$("#settings .date:eq(1)").val(serverInfos.settings.troisiemeTrimestre).trigger('change');
});




// Couleur

$("#colorSelector span").click(function() {
	switchColorTo($(this).index()-1);
	updateOptionFile();
});



// Générale

$("#loginAuto").click(function() {
	Options.autoLogin = this.checked;
	updateOptionFile();
});

$("#urlTs").change(function(e) {
	var val = $(this).val().match("^https?:\/\/[a-z\._\-]+");
	if (val)
		Options.baseUrl = val[0];

	$(this).val(Options.baseUrl);
	baseUrl = Options.baseUrl + "/ts-mobile/resources/eleves/";

	updateOptionFile();
});