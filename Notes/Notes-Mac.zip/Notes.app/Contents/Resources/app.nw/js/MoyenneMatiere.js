/*

Calcul de la moyenne par matière

© Guillaume Gonnet
License GPLv2

*/




var currentNotes, currentRec = [], currentLength = 0, nbrRecieved = 0;
var time2Trim = 0,
	time3Trim = 0;


// Quand on click sur une mtière
function onClickMatiere() {

	currentNotes = [[],[],[],[]];
	$("#cache").fadeIn();


	var id = $(this).attr("data-id"),
		index = $(this).attr("data-i"),
		titre = $(this).text();


	// On récupère les notes
	$.get(baseUrl+eleveId+"/matieres/"+id+"/controles/?index=0&offset=200", function(d) {
		
		currentRec = d;

		// On met le titre
		$("#notes h3 span").text(titre);

		// On enlève les anciennes notes
		$("#noteContent p").remove();
		$("#noteContent div").show();

		
		// On récupère les date des trimestres
		time2Trim = parseDate(Options.deuxiemeTrimestre);
		time3Trim = parseDate(Options.troisiemeTrimestre);


		var moyenne = [0,0,0,0];
		var surCombien = [0,0,0,0];

		currentLength = d.length;
		nbrRecieved = 0;


		for (var i in d) {
			
			// On choisis le trimestre correspondant à la note
			var index = 3;
			if (d[i].date < time2Trim)
				index = 1;
			else if (d[i].date < time3Trim)
				index = 2;

			$("#noteContent .c"+index+"Trim").append('<p data-id='+d[i].id+'></p>');
			$.get(baseUrl+eleveId+"/matieres/"+id+"/controles/"+d[i].id+"?index=&offset=", onNoteRecieve);
		}


		// Si pas de note dans un trimestre, on cache ce trimestre
		for (var i = 1; i <= 3; i++) {
			if ($("#noteContent .c"+i+"Trim p").length == 0) {
				$("#noteContent .c"+i+"Trim").hide();
			}
		}

	});
}






/*
	On reçoit une note
*/

function onNoteRecieve(d) {
	var $elem = $("#noteContent p[data-id="+d.id+"]");

	// On choisis le trimestre correspondant à la note
	var index = 3;
	if (d.date < time2Trim)
		index = 1;
	else if (d.date < time3Trim)
		index = 2;

	currentNotes[index].push(d);
	currentNotes[0].push(d);


	// On affiche les infos de cette note
	$elem.append(d.libelle + ': ');

	if (d.note != -1)
		$elem.append(d.note+' / '+d.surCombien);
	else
		$elem.append('Abs');

	$elem.append(' &nbsp;&nbsp;&nbsp; coeff: '+d.coefficient);
	$elem.append('<br><small>Le '+new Date(d.date).toLocaleDateString()+', &nbsp;&nbsp;&nbsp; Min: '+parseFloat(d.noteMin)+' &nbsp;&nbsp;&nbsp; Moy: '+parseFloat(d.moyenne)+' &nbsp;&nbsp;&nbsp; Max: '+parseFloat(d.noteMax)+'</small>');

	updateNoteRecieve();
}







/*
	Vérifie si toute les notes ont été reçus
*/

function updateNoteRecieve() {
	nbrRecieved++;
	if (nbrRecieved >= currentLength) {

		for (var i = 1; i <= 3; i++) {
			$("#noteContent .c"+i+"Trim h4 span").text(calculerMoyenne(currentNotes[i]));
			$("#noteContent .c"+i+"Trim h4 small").text('Classe: '+calculerMoyenne(currentNotes[i], true));
		}

		$("#notes .moyenne span").text(calculerMoyenne(currentNotes[0]))
		$("#notes .moyenne small").text('Classe: '+calculerMoyenne(currentNotes[0], true));


		// On affiche les notes
		$("#view").css("margin-left", "-100%");
		$("#cache").fadeOut();
	}
}




// Boutton "<-"
$("#notes i").click(function() {
	$("#view").css("margin-left", 0);
});