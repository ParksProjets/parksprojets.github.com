/*

Affichage du graphique

© Guillaume Gonnet
License GPLv2

*/



const graphOptions = {
	yaxis: {
		min: 0,
		max: 20
	},
	xaxis: {
		show: false
	}
};


// Boutton "Graphique"
$("#goToGraph").click(function() {
	$("#view").css("margin-left", "-200%");

	var donnees = [], l = currentRec.length-1;
	for (var i = l; i >= 0; i--) {
		if (currentRec[i].note >= 0)
			donnees.push([ l-i, currentRec[i].note / currentRec[i].surCombien * 20 ]);
	}

	$.plot("#graph .placeholder", [{

		data: donnees,
		lines: { show: true },
		points: { show: true }

	}], graphOptions);

});


// Boutton "<-"
$("#graph i").click(function() {
	$("#view").css("margin-left", "-100%");
});