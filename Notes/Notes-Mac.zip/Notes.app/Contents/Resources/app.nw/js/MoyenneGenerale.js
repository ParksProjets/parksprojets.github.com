/*

Calcul de la moyenne générale

© Guillaume Gonnet
License GPLv2

*/



var genLength = 0, currentGenLength = 0, allMatRec = true;
var genNotes = {};


$("#matieres .moyenne button").click(function() {

	// Si le boutton est désactivé, on quitte
	if ($(this).hasClass('off'))  return;

	// On change le css
	$("#matieres .moyenne img").css("opacity", 1);
	$(this).addClass('off');
	$("#matieres .moyenne .result").css("opacity", 0);

	var selected = $("#matieres .moyenne option:selected").val();
	var min = 0, max = 0;

	genNotes = {};
	genLength = 0;
	currentGenLength = 0;
	allMatRec = false;


	// On regarde les dates selon le choix de l'utilisateur
	if (selected == "trim1") {
		max = parseDate(Options.deuxiemeTrimestre);
	}
	else if (selected == "trim2") {
		min = parseDate(Options.deuxiemeTrimestre);
		max = parseDate(Options.troisiemeTrimestre);
	}
	else if (selected == "trim3") {
		min = parseDate(Options.troisiemeTrimestre);
	}


	matieres.forEach(function(mat, i) {

		// On récupère les id des notes dans chaque matière
		$.get(baseUrl+eleveId+"/matieres/"+mat.id+"/controles/?index=0&offset=200", function(d) {

			genNotes[mat.id] = [];
			
			for (var j in d) {

				// Si la note correspond avec les dates
				if ((!min || d[j].date >= min) && (!max || d[j].date <= max)) {
					genLength++;
					genGetNotes(mat.id, d[j].id);
				}
			}


			// Toutes les matières ont été reçus
			if (i >= matieres.length-1) {
				allMatRec = true;

				// Il n'y à aucune note correspondante avec les dates
				if (genLength == 0) {
					$("#matieres .moyenne img").css("opacity", 0);
					$("#matieres .moyenne button").removeClass('off');
				}
			}

		});
	});
});







/*
	Recoi les notes une par une
*/

function genGetNotes(idMat, idNote) {

	// On appelle l'URL
	$.get(baseUrl+eleveId+"/matieres/"+idMat+"/controles/"+idNote+"?index=&offset=", function (d) {
		
		// On stock la note dans le tableau des notes
		genNotes[idMat].push(d);

		// On vérifie si toute les notes ont été reçus 
		updateGenRec();
	});

}







/*
	Vérifie si toute les notes ont été reçus
*/

function updateGenRec() {
	currentGenLength++;

	if (allMatRec && currentGenLength >= genLength) {

		$("#matieres .moyenne img").css("opacity", 0);
		$("#matieres .moyenne button").removeClass('off');


		// On calcul la moyenne de chaque matière
		var sousMoyennesEleve = [], sousMoyennesClasse = [];
		for (var i in genNotes) {
			sousMoyennesEleve.push(calculerMoyenne(genNotes[i]));
			sousMoyennesClasse.push(calculerMoyenne(genNotes[i], true));
		}


		// On calcul la moyenne générale
		var moyenneEleve = 0, moyenneClasse = 0;
		for (var i in sousMoyennesEleve) {
			moyenneEleve += sousMoyennesEleve[i];
			moyenneClasse += sousMoyennesClasse[i];
		}

		moyenneEleve = Math.round( moyenneEleve / sousMoyennesEleve.length * 10) / 10;
		moyenneClasse = Math.round( moyenneClasse / sousMoyennesEleve.length * 10) / 10;


		// On affiche les moyennes
		$("#matieres .moyenne .result span:eq(0)").text(moyenneEleve);
		$("#matieres .moyenne .result span:eq(1)").text(moyenneClasse);
		$("#matieres .moyenne .result").css("opacity", 1);

	}
}
